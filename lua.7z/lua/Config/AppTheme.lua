require("catppuccin").setup({
    integrations = {
        cmp = true,
        nvimtree = true,
        treesitter = true,
        notify = true,
    }
})
vim.cmd.colorscheme("catppuccin-latte");
vim.cmd.colorscheme("catppuccin-latte");
