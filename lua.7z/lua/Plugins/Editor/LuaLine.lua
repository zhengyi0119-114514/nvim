require("lualine").setup({
    options = {
        theme = "catppuccin"
    }
})